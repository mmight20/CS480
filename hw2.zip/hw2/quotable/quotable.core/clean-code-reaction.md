I tend to use "magic" strings. Rather than creating a constant or final variable I usually hard code a variable in an if statement.

I was surprised by the functional tip to avoid using conditionals. We frequently use if statements and switches. 
But I understand how using classes that implement an interface can be more beneficial.


I do not necessarily agree nor disagree with the tip to not use the Singleton Pattern. In the Design Patterns course that I took last semester we discussed this pattern
so I am concerned that one of the tips for clean code is to never use this pattern, which is refered to as an anti-pattern.