﻿using System;

namespace quotable.core
{
    public class Class1
    {
    }
}
